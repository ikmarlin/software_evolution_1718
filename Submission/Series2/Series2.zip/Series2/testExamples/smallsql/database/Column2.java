package smallsql.database;
import java.io.*;
import java.nio.channels.FileChannel;
import java.sql.*;
import smallsql.database.language.Language;
class Column2 implements Cloneable{  
    private Expression defaultValue = Expression.NULL; // Default value for INSERT
    private String defaultDefinition; // String representation for Default Value
    private String name;
package smallsql.database;
import java.io.*;
import java.nio.channels.FileChannel;
import java.sql.*;
import smallsql.database.language.Language;
class Column2 implements Cloneable{  
    private Expression defaultValue = Expression.NULL; // Default value for INSERT
    private String defaultDefinition; // String representation for Default Value
    private String name;
package smallsql.database;
import java.io.*;
import java.nio.channels.FileChannel;
import java.sql.*;
import smallsql.database.language.Language;
class Column2 implements Cloneable{  
    private Expression defaultValue = Expression.NULL; // Default value for INSERT
    private String defaultDefinition; // String representation for Default Value
    private String name;
    